import yfinance as yf
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
stock = yf.download("AAPL", period="1y")
print(stock.head())
stock = stock[['Open', 'High', 'Low', 'Volume', 'Close']]

stock['Target'] = stock['Close'].shift(-1)

stock = stock.dropna()

X = stock[['Open', 'High', 'Low', 'Volume']]
y = stock['Target']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, shuffle=False)
model = LinearRegression()
model.fit(X_train, y_train)
predictions = model.predict(X_test)
plt.figure(figsize=(10,5))

plt.plot(y_test.values, label="Actual Price")
plt.plot(predictions, label="Predicted Price")

plt.legend()
plt.title("Actual vs Predicted Stock Prices")
plt.show()