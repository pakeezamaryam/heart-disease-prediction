import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns


# how to load data
data =pd.read_csv("iris_dataset.csv")
print (data)
# how to print shape
print(data.shape)
# how to print columns name
print(data.columns)
print(data.head(10))
# how to print the details not nulllike
print(data.info())
# how to print count averge std
print(data.describe())

# print fig through matplotlib
plt.scatter(data["sepal_length"],data["petal_length"])
plt.xlabel("Age")
plt.ylabel("Salary")
plt.title("Age vs Salary")
plt.show()

# print fig through seasoborn
sns.scatterplot(x=data["sepal_length"],y=data["petal_length"])
plt.show()
# print fig through seasoborn
sns.scatterplot(
    x="sepal_length",
    y="petal_length",
    hue="species",
    data=data
)
plt.show()

sns.histplot(x="petal_length", hue="species", data=data)
plt.show()

sns.boxplot(x="species", y="petal_length", data=data)
plt.show()
